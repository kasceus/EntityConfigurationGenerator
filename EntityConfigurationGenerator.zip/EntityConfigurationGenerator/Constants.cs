﻿namespace EntityConfigurationGenerator
{
    internal class Constants
    {
        internal const string PackageGuidString = "08cd4165-b5ac-4b54-b5cb-9baebef59972";
    }
}
