﻿namespace EntityConfigurationGenerator
{
	public class EntityConfigGeneratorSettings
	{
		public bool GenerateAsPartial { get; set; }
	}
}
