﻿using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;


namespace EntityConfigurationGenerator
{
    [PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    [Guid(ExtensionPackage.PackageGuidString)]
    [ProvideOptionPage(typeof(EntityConfigOptionsPage), "Entity Config Generator", "Settings", 0, 0, true)]
    [ProvideAutoLoad(UIContextGuids80.SolutionExists, PackageAutoLoadFlags.BackgroundLoad)]

    public sealed class ExtensionPackage : AsyncPackage
    {
        public const string PackageGuidString = Constants.PackageGuidString;
        public ExtensionPackage()
        {
        }
        #region Package Members
        protected override async Task InitializeAsync(CancellationToken cancellationToken, IProgress<ServiceProgressData> progress)
        {
            await this.JoinableTaskFactory.SwitchToMainThreadAsync(cancellationToken);
            try
            {
                await ToggleUsePartialsCommand.InitializeAsync(this);

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            await GenerateSingleConfigurationCommand.InitializeAsync(this);
            await GenerateAllConfigurationsCommand.InitializeAsync(this);
            await EntityConfigurationGenerator.Menus.ExtensionsMenu.Command1.InitializeAsync(this);
        }

        #endregion
    }
}
