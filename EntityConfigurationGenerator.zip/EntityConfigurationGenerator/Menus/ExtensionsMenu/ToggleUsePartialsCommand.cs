﻿using EntityConfigurationGenerator.Menus.ExtensionsMenu;

using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;

using System;
using System.ComponentModel.Design;
using System.Threading.Tasks;

namespace EntityConfigurationGenerator
{
    internal sealed class ToggleUsePartialsCommand
    {
        private readonly OleMenuCommand _MenuItem;
        private readonly AsyncPackage _Package;

        private ToggleUsePartialsCommand(AsyncPackage package, OleMenuCommandService commandService)
        {
            this._Package = package ?? throw new ArgumentNullException(nameof(package));
            var outputPane = GetOutputPaneAsync().Result;
            var menuCommandID = new CommandID(MenuConstants._CommandSet, MenuConstants._ToggleUsePartialsCommandId);
            _MenuItem = new OleMenuCommand(Execute, menuCommandID);
            var settings = (EntityConfigOptionsPage)_Package.GetDialogPage(typeof(EntityConfigOptionsPage));
            _MenuItem.Text = settings.GenerateAsPartial ? "Use Partials" : "Use Partials";
            _MenuItem.Checked = settings.GenerateAsPartial;
            commandService.AddCommand(_MenuItem);
            _MenuItem.Visible = true;
            _MenuItem.Enabled = true;
        }
        private async Task<IVsOutputWindowPane> GetOutputPaneAsync()
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();

            var outputWindow = (IVsOutputWindow)await _Package.GetServiceAsync(typeof(SVsOutputWindow));
            Guid paneGuid = new Guid("e1d890f1-d191-45e2-9ad9-bfcf993003c1"); // your own unique GUID
            string title = "Entity Configuration Generator";

            outputWindow.CreatePane(ref paneGuid, title, fInitVisible: 1, fClearWithSolution: 1);
            outputWindow.GetPane(ref paneGuid, out IVsOutputWindowPane pane);

            return pane;
        }

        public static async Task InitializeAsync(AsyncPackage package)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);

            var commandService = await package.GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (commandService != null)
            {

                var d = new ToggleUsePartialsCommand(package, commandService);
                var outputPane = await d.GetOutputPaneAsync();
                outputPane.OutputStringThreadSafe("Initializing ToggleUsePartials");
                outputPane.Activate(); // Bring the pane to front
            }

        }

        private void Execute(object sender, EventArgs e)
        {
            ThreadHelper.ThrowIfNotOnUIThread();

            var settings = (EntityConfigOptionsPage)_Package.GetDialogPage(typeof(EntityConfigOptionsPage));

            settings.GenerateAsPartial = !settings.GenerateAsPartial;
            if (sender is OleMenuCommand menuCommand)
            {
                _MenuItem.Text = settings.GenerateAsPartial ? "Use Partials" : "Use Partials";
            }

            VsShellUtilities.ShowMessageBox(
                _Package,
                $"Generate as Partial is now {(settings.GenerateAsPartial ? "ON" : "OFF")}.",
                "Configuration Updated",
                OLEMSGICON.OLEMSGICON_INFO,
                OLEMSGBUTTON.OLEMSGBUTTON_OK,
                OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST
            );
        }
    }

}
