﻿using System;

namespace EntityConfigurationGenerator.Menus.ExtensionsMenu
{
    internal static class MenuConstants
    {
        internal static Guid _CommandSet = new Guid("33b9a065-3e45-4f15-8c28-cfb1303db805");
        internal const int _ToggleUsePartialsCommandId = 0x0012;
    }
}
